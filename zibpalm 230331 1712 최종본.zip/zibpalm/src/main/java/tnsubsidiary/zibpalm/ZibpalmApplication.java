package tnsubsidiary.zibpalm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZibpalmApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZibpalmApplication.class, args);
	}

}
