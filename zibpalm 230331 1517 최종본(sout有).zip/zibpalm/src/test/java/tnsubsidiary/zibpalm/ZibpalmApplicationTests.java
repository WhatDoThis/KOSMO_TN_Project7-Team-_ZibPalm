package tnsubsidiary.zibpalm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZibpalmApplicationTests {

	@Test
	void contextLoads() {
	}

}
